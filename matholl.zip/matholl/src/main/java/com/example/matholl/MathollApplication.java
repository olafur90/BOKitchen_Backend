package com.example.matholl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MathollApplication {

	public static void main(String[] args) {
		SpringApplication.run(MathollApplication.class, args);
	}

}
